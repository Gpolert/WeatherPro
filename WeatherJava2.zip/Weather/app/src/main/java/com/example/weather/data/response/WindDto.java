package com.example.weather.data.response;

public class WindDto {
    public Double speed;

    public WindDto(Double speed) {
        this.speed = speed;
    }
}
